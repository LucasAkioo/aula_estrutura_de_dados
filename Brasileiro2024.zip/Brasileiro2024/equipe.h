#ifndef EQUIPE_H
#define EQUIPE_H

typedef struct {

    int Posicao;
    char Estado[32];
    char Time[32]; // Nome da equipe (na tabela, está coluna "Equipe")
    int Pontos;
    int J;
    int V;
    int E;
    int D;
    int GP;
    int GC;
    int SG;
    float Aproveitamento;

} Equipe;

#define ERRO -999

Equipe * lerTabela (char * Arquivo);

int getGP(Equipe * T, char * Time);

#endif

//Pts;J;V;E;D;GP;GC;SG
