#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "equipe.h"


Equipe * lerTabela (char * Arquivo) {

    FILE * fp = fopen(Arquivo, "r");

    if(fp == NULL) {
        printf("ERRO: o arquivo não pode ser aberto!\n");
        exit(1);
    }

    Equipe * X = malloc(20 * sizeof(Equipe));

    if (X == NULL) {
        printf("ERRO: não há memória para armazenar o vetor de structs.\n");
        exit(1);
    }

    char Buffer[100];
    fscanf(fp, "%s", Buffer); // Para "pular" a primeira linha

    int N = 0;

    while(
        fscanf(fp, "%d;%[^;];%[^;];%d;%d;%d;%d;%d;%d;%d;%d\n", 
            &X[N].Posicao,
            X[N].Estado,
            X[N].Time,
            &X[N].Pontos,
            &X[N].J,
            &X[N].V,
            &X[N].E,
            &X[N].D,
            &X[N].GP, 
            &X[N].GC,
            &X[N].SG
        ) == 11

    ) {

        X[N].Aproveitamento = 100.0 * X[N].Pontos / (3.0 * X[N].J);
        N++;

    }

    fclose(fp);
    return X;

}

int getGP(Equipe * T, char * Time) {

    for (int i = 0; i < 20; i++) {
        if(strcmp(Time, T[i].Time) == 0) {
            return T[i].GP;
        }
    }

    return ERRO;

}