#include <stdio.h>
#include <stdlib.h>

#include "equipe.h"

int main() {

    Equipe * Tabela = lerTabela("tabela2024.csv");

    for(int N = 0; N < 20; N++)
        printf("%d \t %s \t %.2f \n", Tabela[N].Posicao, Tabela[N].Time, Tabela[N].Aproveitamento);

    int gols_1 = getGP(Tabela, "Flamengo");
    printf("Gols do Flamengo: %d \n", gols_1);

    int gols_2 = getGP(Tabela, "Santos");
    printf("Gols do Santos: %d \n", gols_2);

}