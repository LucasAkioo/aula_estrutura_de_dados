#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "lista.h"

int main() {

    // 2ª forma: declarando um ponteiro P para o tipo Tarefa

    Tarefa * P = (Tarefa *) malloc(sizeof(Tarefa));

    if (P == NULL) {
        printf("ERRO: não há memória para armazenar uma tarefa!\n");
        exit(1);
    }

    // Obs: usa-se -> pois P é PONTEIRO para a struct Tarefa

    strcpy (P->Titulo, "Estudar para a prova de Matemática");
    strcpy (P->Responsavel, "André");
    P->Status = EM_DESENVOLVIMENTO;
    P->Progresso = 0.60;
    P->Avaliacao = 4; // Prioridade alta

    system ("cls");
    printf("Endereço da struct: %X\n", P);
    printf("%s \n", P->Titulo);

    return 0;

}
