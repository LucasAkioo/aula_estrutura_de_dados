#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "lista.h"

int main() {

    // 3ª forma: declarando e inicializando a variável struct

    Tarefa P = {"Estudar para a prova de Matemática", "André", EM_DESENVOLVIMENTO, 0.60, 4};

    system ("cls");
    printf("Endereço da struct: %X\n", &P);
    printf("%s \n", P.Titulo);

    return 0;

}
