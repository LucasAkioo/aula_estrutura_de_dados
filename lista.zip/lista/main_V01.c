#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "lista.h"

int main() {

    // 1ª forma: declarando uma variável P do tipo Tarefa

    Tarefa P;

    strcpy (P.Titulo, "Estudar para a prova de Matemática");
    strcpy (P.Responsavel, "André");
    P.Status = EM_DESENVOLVIMENTO;
    P.Progresso = 0.60;
    P.Avaliacao = 4; // Prioridade alta

    system ("cls");
    printf("%s \n", P.Titulo);

    return 0;

}
